# Checklist de montagem — Seminário Horizonte 2027

**Data:** 10 de maio de 2027
**Local:** Auditório 2 — Instituto Horizonte — Centro de Formação
**Início da montagem:** 7h30

## Auditório 2

- [ ] Abrir o auditório e conferir a limpeza.
- [ ] Testar o projetor e o computador da apresentação.
- [ ] Testar os microfones de lapela e sem fio.
- [ ] Organizar 120 cadeiras, deixando corredores livres.
- [ ] Reservar as primeiras fileiras para palestrantes e convidados.
- [ ] Colocar água nas mesas de apoio.

## Recepção e credenciamento

- [ ] Montar a mesa de credenciamento com a lista de presença.
- [ ] Separar crachás, cordões e canetas.
- [ ] Sinalizar a entrada do Auditório 2.
- [ ] Deixar o cartaz do evento visível na porta.

## Coffee break

- [ ] Confirmar a entrega do café da manhã às 8h.
- [ ] Confirmar o café da tarde para as 15h30.
- [ ] Providenciar água e copos para o dia inteiro.

## No fim do dia

- [ ] Recolher os crachás e a lista de presença.
- [ ] Conferir se nenhum equipamento ficou ligado.
- [ ] Fechar o Auditório 2 e devolver a chave na recepção.
