# Seminário Horizonte 2027

**Organização, comunicação e tecnologia no dia a dia do trabalho**

## Um dia para pensar a rotina

O Seminário Horizonte 2027 reúne profissionais de áreas diferentes para conversar sobre o que ajuda — e o que atrapalha — na organização do trabalho. A programação inclui palestra, mesa-redonda, oficinas e uma roda de conversa com os participantes.

## Quando e onde

- **Data:** 10 de maio de 2027
- **Horário:** das 9h às 17h
- **Local:** Auditório 2 do Instituto Horizonte — Centro de Formação
- **Endereço:** Rua das Acácias, 140 — Jardim Claro — Cidade de Vale Verde

## Programação

- 08h30 — Credenciamento
- 09h00 — Abertura
- 09h30 — Palestra: Organizar o trabalho sem complicação
- 11h00 — Mesa-redonda: Comunicação que funciona
- 14h00 — Oficinas simultâneas
- 16h00 — Roda de conversa
- 17h00 — Encerramento

## Inscrições

As inscrições estão abertas pelo site do Instituto e pelo e-mail seminario@institutohorizonte.exemplo.com. A participação é gratuita e as vagas são limitadas a 120 pessoas.

## Certificados

Recebe certificado quem participar de pelo menos 75% da programação. O certificado é enviado por e-mail em até 10 dias úteis após o evento.
